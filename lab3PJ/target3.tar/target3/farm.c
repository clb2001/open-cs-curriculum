/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_168()
{
    return 2496104776U;
}

unsigned getval_448()
{
    return 3347667070U;
}

unsigned getval_387()
{
    return 3284633928U;
}

unsigned getval_247()
{
    return 2425393176U;
}

unsigned addval_452(unsigned x)
{
    return x + 3284633928U;
}

void setval_382(unsigned *p)
{
    *p = 3277345148U;
}

void setval_489(unsigned *p)
{
    *p = 666982417U;
}

unsigned getval_137()
{
    return 4039348312U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_468(unsigned x)
{
    return x + 3523789193U;
}

unsigned getval_214()
{
    return 2425539209U;
}

unsigned addval_125(unsigned x)
{
    return x + 3375945225U;
}

void setval_163(unsigned *p)
{
    *p = 3224945049U;
}

void setval_261(unsigned *p)
{
    *p = 3677932169U;
}

void setval_243(unsigned *p)
{
    *p = 3286272328U;
}

void setval_140(unsigned *p)
{
    *p = 3767101674U;
}

unsigned addval_191(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_257(unsigned x)
{
    return x + 3524843145U;
}

unsigned addval_492(unsigned x)
{
    return x + 3531921032U;
}

void setval_156(unsigned *p)
{
    *p = 3372799625U;
}

unsigned getval_399()
{
    return 2430601544U;
}

void setval_412(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_290(unsigned x)
{
    return x + 3683961481U;
}

unsigned getval_270()
{
    return 3247164504U;
}

unsigned getval_139()
{
    return 3380920777U;
}

unsigned getval_164()
{
    return 3252717896U;
}

void setval_459(unsigned *p)
{
    *p = 3281049227U;
}

unsigned addval_430(unsigned x)
{
    return x + 3225998985U;
}

unsigned addval_334(unsigned x)
{
    return x + 3281043913U;
}

void setval_221(unsigned *p)
{
    *p = 3536112265U;
}

unsigned getval_252()
{
    return 3525364361U;
}

unsigned getval_474()
{
    return 3229931145U;
}

void setval_238(unsigned *p)
{
    *p = 3526937227U;
}

unsigned getval_241()
{
    return 3230979721U;
}

unsigned addval_376(unsigned x)
{
    return x + 2447411528U;
}

void setval_145(unsigned *p)
{
    *p = 3674784136U;
}

unsigned addval_319(unsigned x)
{
    return x + 3523791561U;
}

void setval_287(unsigned *p)
{
    *p = 3758704834U;
}

unsigned getval_380()
{
    return 2428570005U;
}

unsigned addval_421(unsigned x)
{
    return x + 2429159792U;
}

unsigned getval_343()
{
    return 2425405833U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
